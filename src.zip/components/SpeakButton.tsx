import React, { useState, useEffect } from "react";
import { Volume2, VolumeX } from "lucide-react";

interface SpeakButtonProps {
  text: string;
  className?: string;
}

const SPEECH_RATE = 0.75;

export default function SpeakButton({ text, className = "" }: SpeakButtonProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = React.useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    return () => {
      if (typeof window !== "undefined" && window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, []);

  const handleSpeak = (e: React.MouseEvent) => {
    e.stopPropagation();

    const hasSpeechSynthesis = typeof window !== "undefined" && window.speechSynthesis;

    if (isPlaying) {
      if (hasSpeechSynthesis) {
        window.speechSynthesis.cancel();
      }
      if (audioRef.current) {
        audioRef.current.pause();
      }
      setIsPlaying(false);
      return;
    }

    if (!hasSpeechSynthesis) {
      // Fallback for Median.co and mobile webview wrappers lacking standard SpeechSynthesis API.
      if (audioRef.current) {
        audioRef.current.pause();
      }

      const audioUrl = `/api/tts?q=${encodeURIComponent(text)}&tl=de`;
      const audio = new Audio(audioUrl);
      audio.playbackRate = SPEECH_RATE;
      audioRef.current = audio;

      audio.onended = () => {
        setIsPlaying(false);
      };

      audio.onerror = () => {
        setIsPlaying(false);
      };

      setIsPlaying(true);

      // Attempt play, handling auto-play policy constraints
      audio.play().catch((err) => {
        console.error("Audio playback failed:", err);
        setIsPlaying(false);
      });
      return;
    }

    // Cancel current speaking
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "de-DE";
    utterance.rate = SPEECH_RATE;

    // Retrieve German voices and always prefer a female voice (Hedda, Katrin, etc.)
    const voices = window.speechSynthesis.getVoices();
    const deVoices = voices.filter(v => v.lang.startsWith("de"));

    if (deVoices.length > 0) {
      const femalePatterns = ["hedda", "katrin", "katja", "female", "woman", "de-de-f"];
      const foundFemale = deVoices.find(v =>
        femalePatterns.some(p => v.name.toLowerCase().includes(p))
      );
      utterance.voice = foundFemale || deVoices[0];
    }

    utterance.onend = () => {
      setIsPlaying(false);
    };

    utterance.onerror = () => {
      setIsPlaying(false);
    };

    setIsPlaying(true);
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className={`inline-flex items-center gap-1.5 ${className}`} dir="rtl">
      <button
        onClick={handleSpeak}
        className={`p-1.5 rounded-lg border transition-all flex items-center justify-center cursor-pointer ${
          isPlaying
            ? "bg-cyan-500/20 text-cyan-300 border-cyan-500"
            : "bg-slate-900 border-slate-800 text-slate-300 hover:text-white hover:border-slate-700"
        }`}
        title="استمع للنطق الألماني (سرعة 0.75x)"
      >
        {isPlaying ? (
          <VolumeX className="w-4 h-4 animate-pulse" />
        ) : (
          <Volume2 className="w-4 h-4" />
        )}
      </button>
    </div>
  );
}
