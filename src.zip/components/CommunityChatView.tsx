import React, { useState, useEffect, useRef, useCallback } from "react";
import { UserProfile } from "../types";
import { Send, Users, RefreshCw, AlertCircle, Mic, Square, Globe2 } from "lucide-react";
import { motion } from "motion/react";
import { useSpeechDictation } from "./MicWidget";

interface CommunityChatViewProps {
  profile: UserProfile;
}

interface CommunityMessage {
  id: string;
  userEmail: string;
  userName: string;
  content: string;
  createdAt: string;
}

const POLL_INTERVAL_MS = 4000;

export default function CommunityChatView({ profile }: CommunityChatViewProps) {
  const [messages, setMessages] = useState<CommunityMessage[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const { isRecording, dictationStatus, errorMessage: dictationError, start: startDictation, stop: stopDictation } = useSpeechDictation({
    onResult: (transcript) => {
      setInput((prev) => (prev ? `${prev} ${transcript}` : transcript));
    },
  });

  const fetchMessages = useCallback(async (silent = true) => {
    try {
      const response = await fetch("/api/community/messages");
      if (!response.ok) throw new Error("فشل تحميل رسائل المجتمع.");
      const data = await response.json();
      if (data.success) {
        setMessages(data.messages || []);
        if (!silent) setErrorMessage("");
      }
    } catch (e: any) {
      if (!silent) setErrorMessage(e?.message || "حدث خطأ أثناء تحميل رسائل المجتمع.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Initial load + polling for new messages
  useEffect(() => {
    fetchMessages(false);
    pollRef.current = setInterval(() => fetchMessages(true), POLL_INTERVAL_MS);
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [fetchMessages]);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    setTimeout(() => {
      bottomRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  }, [messages]);

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed || isSending) return;

    setIsSending(true);
    setErrorMessage("");

    try {
      const response = await fetch("/api/community/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: profile.email, content: trimmed }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || "فشل إرسال الرسالة.");
      }

      setInput("");
      // Optimistically append, then re-sync shortly after
      setMessages((prev) => [...prev, data.message]);
    } catch (e: any) {
      setErrorMessage(e?.message || "حدث خطأ غير متوقع أثناء إرسال الرسالة.");
    } finally {
      setIsSending(false);
    }
  };

  const myEmail = (profile.email || "").toLowerCase().trim();

  const formatTime = (iso: string) => {
    try {
      return new Date(iso).toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" });
    } catch {
      return "";
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-4 w-full" dir="rtl">
      {/* Header */}
      <div className="p-5 rounded-3xl bg-slate-900/60 border border-blue-950/40 backdrop-blur-md flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-blue-950/80 rounded-2xl border border-blue-500/20 text-blue-400 shrink-0">
            <Globe2 className="w-5 h-5" />
          </div>
          <div>
            <span className="text-sm font-bold text-white block">مجتمع متعلمي الألمانية</span>
            <span className="text-[11px] text-slate-400 leading-relaxed">
              غرفة دردشة عامة لتتحدث وتتدرب مع متعلمين آخرين باللغة الألمانية في الوقت الفعلي.
            </span>
          </div>
        </div>
        <div className="flex items-center gap-1.5 text-[10px] text-slate-400 bg-slate-950/60 border border-slate-900 px-2.5 py-1 rounded-full shrink-0">
          <Users className="w-3.5 h-3.5 text-cyan-400" />
          <span>غرفة عامة</span>
        </div>
      </div>

      {/* Messages list */}
      <div className="rounded-3xl border border-blue-950/40 bg-slate-950/70 p-4 sm:p-5 h-[420px] sm:h-[480px] flex flex-col">
        <div className="flex-grow overflow-y-auto space-y-3 pr-1 scrollbar-thin scrollbar-thumb-blue-950 scrollbar-track-transparent">
          {isLoading ? (
            <div className="h-full flex items-center justify-center text-slate-500 text-xs gap-2">
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>جاري تحميل المحادثة...</span>
            </div>
          ) : messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center gap-2 px-6">
              <Globe2 className="w-8 h-8 text-blue-500/60" />
              <p className="text-sm text-slate-400">لا توجد رسائل بعد. كن أول من يبدأ المحادثة بالألمانية!</p>
            </div>
          ) : (
            messages.map((msg) => {
              const isMine = msg.userEmail.toLowerCase().trim() === myEmail;
              return (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.2 }}
                  className={`flex ${isMine ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl p-3 border space-y-1 ${
                      isMine
                        ? "bg-blue-950/60 border-blue-800/40 rounded-tl-none"
                        : "bg-slate-900/80 border-blue-950/80 rounded-tr-none"
                    }`}
                  >
                    {!isMine && (
                      <span className="text-[10px] font-bold text-cyan-400 block">{msg.userName}</span>
                    )}
                    <p className="text-sm font-sans text-white leading-relaxed break-words" dir="auto">
                      {msg.content}
                    </p>
                    <span className="text-[9px] text-slate-500 block text-left" dir="ltr">
                      {formatTime(msg.createdAt)}
                    </span>
                  </div>
                </motion.div>
              );
            })
          )}
          <div ref={bottomRef} />
        </div>
      </div>

      {/* Error messages */}
      {(errorMessage || dictationError) && (
        <div className="p-3 rounded-xl bg-red-950/40 border border-red-900/50 flex items-center gap-2 text-xs text-red-300">
          <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
          <span>{errorMessage || dictationError}</span>
        </div>
      )}

      {/* Dictation status badge */}
      {dictationStatus && !errorMessage && (
        <div className={`p-2.5 rounded-xl border flex items-center gap-2 text-xs ${
          dictationStatus === "recording"
            ? "bg-red-950/40 border-red-900/40 text-red-300"
            : dictationStatus === "processing"
            ? "bg-yellow-950/40 border-yellow-905/40 text-yellow-300"
            : "bg-emerald-950/50 border-emerald-900/40 text-emerald-300"
        }`}>
          <span className="flex h-2.5 w-2.5 relative shrink-0">
            {dictationStatus === "recording" && (
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
            )}
            <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${
              dictationStatus === "recording" ? "bg-red-500" : dictationStatus === "processing" ? "bg-yellow-500" : "bg-emerald-500"
            }`} />
          </span>
          <span>
            {dictationStatus === "recording" && "جاري التسجيل... تحدث الآن (يتوقف تلقائياً بعد 5 ثوانٍ من الصمت)"}
            {dictationStatus === "processing" && "جاري معالجة الصوت..."}
            {dictationStatus === "success" && "تم الالتقاط بنجاح"}
          </span>
        </div>
      )}

      {/* Input bar */}
      <form onSubmit={handleSend} className="flex items-center gap-2.5">
        <button
          type="button"
          onClick={isRecording ? stopDictation : startDictation}
          className={`p-3.5 rounded-xl border flex items-center justify-center transition-all cursor-pointer shrink-0 ${
            isRecording
              ? "bg-red-650 text-white border-red-550 animate-pulse shadow-[0_0_15px_rgba(239,68,68,0.4)]"
              : "bg-slate-900 text-slate-400 border-blue-950 hover:text-white"
          }`}
          title="تسجيل رسالة صوتية بالألمانية"
        >
          {isRecording ? <Square className="w-4.5 h-4.5 fill-current" /> : <Mic className="w-4.5 h-4.5" />}
        </button>

        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="اكتب رسالتك هنا بالألمانية أو العربية..."
          className="flex-grow px-4 py-3 bg-slate-900 text-white text-sm border border-blue-950/60 rounded-xl focus:outline-none focus:border-cyan-500 font-sans"
          dir="auto"
        />

        <button
          type="submit"
          disabled={isSending || !input.trim()}
          className="px-5 py-3 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white rounded-xl font-bold transition-all disabled:opacity-45 disabled:cursor-not-allowed flex items-center justify-center cursor-pointer shadow-[0_4px_12px_rgba(59,130,246,0.3)] shrink-0"
          title="إرسال"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
}
