import React, { useEffect, useRef, useState } from "react";
import { Mic, Square } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export type DictationStatus = "" | "recording" | "processing" | "success";

interface MicWidgetProps {
  isRecording: boolean;
  dictationStatus: DictationStatus;
  errorMessage?: string;
  onStart: () => void;
  onStop: () => void;
  disabled?: boolean;
  size?: "sm" | "lg";
  idleLabel?: string;
  recordingLabel?: string;
}

/**
 * Unified microphone control used across the app (AI Chat, Speaking Practice).
 * Provides a consistent waveform/pulse visualization, a dedicated stop button
 * while recording, and status badges for recording / processing / success,
 * with automatic silence handling expected to be managed by the caller (5s).
 */
export default function MicWidget({
  isRecording,
  dictationStatus,
  errorMessage,
  onStart,
  onStop,
  disabled,
  size = "lg",
  idleLabel = "اضغط على الميكروفون لبدء التحدث",
  recordingLabel = "جاري التسجيل... تحدث الآن بوضوح",
}: MicWidgetProps) {
  const dim = size === "lg" ? "w-20 h-20" : "w-14 h-14";
  const iconDim = size === "lg" ? "w-8 h-8" : "w-5.5 h-5.5";

  return (
    <div className="flex flex-col items-center justify-center gap-3 w-full">
      <div className="relative flex items-center justify-center">
        {/* Waveform / sound-awareness rings while recording */}
        <AnimatePresence>
          {isRecording && (
            <>
              <motion.span
                key="ring-1"
                initial={{ opacity: 0.5, scale: 1 }}
                animate={{ opacity: 0, scale: 1.8 }}
                exit={{ opacity: 0 }}
                transition={{ repeat: Infinity, duration: 1.4, ease: "easeOut" }}
                className="absolute inset-0 rounded-full bg-red-500/40"
              />
              <motion.span
                key="ring-2"
                initial={{ opacity: 0.35, scale: 1 }}
                animate={{ opacity: 0, scale: 2.4 }}
                exit={{ opacity: 0 }}
                transition={{ repeat: Infinity, duration: 1.4, ease: "easeOut", delay: 0.35 }}
                className="absolute inset-0 rounded-full bg-red-500/30"
              />
            </>
          )}
        </AnimatePresence>

        <AnimatePresence mode="wait">
          {isRecording ? (
            <motion.button
              key="recording"
              type="button"
              initial={{ scale: 0.9 }}
              animate={{ scale: [1, 1.08, 1] }}
              exit={{ scale: 0.9 }}
              transition={{ repeat: Infinity, duration: 1.3 }}
              onClick={onStop}
              className={`${dim} relative bg-red-600 hover:bg-red-500 text-white rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(220,38,38,0.55)] cursor-pointer`}
              title="إيقاف التسجيل"
            >
              <Square className={`${size === "lg" ? "w-6 h-6" : "w-4 h-4"} fill-current`} />
            </motion.button>
          ) : (
            <motion.button
              key="idle"
              type="button"
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              onClick={onStart}
              disabled={disabled}
              className={`${dim} bg-gradient-to-tr from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-full flex items-center justify-center shadow-[0_0_25px_rgba(6,182,212,0.45)] cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed`}
              title="بدء التسجيل"
            >
              <Mic className={iconDim} />
            </motion.button>
          )}
        </AnimatePresence>
      </div>

      <div className="text-center">
        <span className="text-xs font-bold text-slate-300 block">
          {isRecording ? recordingLabel : idleLabel}
        </span>
        <span className="text-[10px] text-slate-500 block">
          {isRecording ? "اضغط على زر التوقف لإنهاء التسجيل فوراً" : "سيتم إيقاف التسجيل تلقائياً بعد 5 ثوانٍ من الصمت"}
        </span>
      </div>

      {/* Status badge: recording / processing / success / error */}
      {(dictationStatus || errorMessage) && (
        <div className="w-full max-w-md mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={dictationStatus || errorMessage || "idle"}
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 8 }}
              className={`p-3 rounded-xl border flex items-center justify-center gap-3 text-xs text-right w-full ${
                errorMessage
                  ? "bg-red-950/30 border-red-900/40 text-red-300"
                  : dictationStatus === "recording"
                  ? "bg-red-950/40 border-red-900/40 text-red-350"
                  : dictationStatus === "processing"
                  ? "bg-yellow-950/40 border-yellow-905/40 text-yellow-300"
                  : "bg-emerald-950/50 border-emerald-900/40 text-emerald-300"
              }`}
            >
              <span className="flex h-2.5 w-2.5 relative shrink-0">
                {dictationStatus === "recording" && !errorMessage && (
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
                )}
                <span
                  className={`relative inline-flex rounded-full h-2.5 w-2.5 ${
                    errorMessage
                      ? "bg-red-500"
                      : dictationStatus === "recording"
                      ? "bg-red-500"
                      : dictationStatus === "processing"
                      ? "bg-yellow-500"
                      : "bg-emerald-500"
                  }`}
                />
              </span>

              <span className="font-sans font-medium text-slate-200">
                {errorMessage
                  ? errorMessage
                  : dictationStatus === "recording"
                  ? "جاري التسجيل بالألمانية... تحدث الآن بوضوح (يتوقف تلقائياً بعد 5 ثوانٍ من الصمت)"
                  : dictationStatus === "processing"
                  ? "جاري معالجة الصوت..."
                  : "تم الالتقاط بنجاح"}
              </span>
            </motion.div>
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}

/**
 * Shared speech-recognition hook implementing the standardized behavior:
 * - de-DE recognition, single utterance
 * - auto-stop after 5 seconds of silence
 * - status transitions: recording -> processing -> success
 */
export function useSpeechDictation(options: {
  onResult: (transcript: string) => void;
  onError?: (message: string) => void;
}) {
  const [isRecording, setIsRecording] = useState(false);
  const [dictationStatus, setDictationStatus] = useState<DictationStatus>("");
  const [errorMessage, setErrorMessage] = useState("");
  const recognitionRef = useRef<any>(null);
  const silenceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    return () => {
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {
          // no-op
        }
      }
    };
  }, []);

  const resetSilenceTimer = () => {
    if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
    silenceTimerRef.current = setTimeout(() => {
      stop();
    }, 5000);
  };

  const start = () => {
    setErrorMessage("");
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      const msg = "عذراً، متصفحك لا يدعم التعرف الصوتي. يرجى استخدام متصفح Chrome.";
      setErrorMessage(msg);
      options.onError?.(msg);
      return;
    }

    try {
      const rec = new SpeechRecognition();
      rec.lang = "de-DE";
      rec.continuous = false;
      rec.interimResults = false;
      rec.maxAlternatives = 1;

      rec.onstart = () => {
        setIsRecording(true);
        setDictationStatus("recording");
        resetSilenceTimer();
      };

      rec.onspeechstart = () => resetSilenceTimer();
      rec.onsoundstart = () => resetSilenceTimer();

      rec.onresult = (e: any) => {
        if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
        const transcript = e.results[0][0].transcript;
        setDictationStatus("success");
        if (transcript && transcript.trim()) {
          options.onResult(transcript);
        }
        setTimeout(() => setDictationStatus(""), 2000);
      };

      rec.onerror = (err: any) => {
        if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
        let msg = `حدث خطأ في التسجيل: ${err.error}`;
        if (err.error === "no-speech") {
          msg = "لم يتم اكتشاف أي كلام. حاول مرة أخرى.";
        } else if (err.error === "not-allowed") {
          msg = "تم رفض صلاحية الميكروفون في المتصفح.";
        }
        setErrorMessage(msg);
        options.onError?.(msg);
        setIsRecording(false);
        setDictationStatus("");
      };

      rec.onend = () => {
        if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
        setIsRecording(false);
        setDictationStatus((prev) => (prev === "success" ? "success" : ""));
      };

      recognitionRef.current = rec;
      rec.start();
    } catch (e) {
      setIsRecording(false);
      setDictationStatus("");
    }
  };

  const stop = () => {
    if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
    if (recognitionRef.current) {
      setDictationStatus("processing");
      try {
        recognitionRef.current.stop();
      } catch {
        // no-op
      }
      setIsRecording(false);
    }
  };

  const reset = () => {
    setErrorMessage("");
    setDictationStatus("");
  };

  return { isRecording, dictationStatus, errorMessage, start, stop, reset };
}
